'use client';
import { useEffect, useState } from 'react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleMode = () => {
    const newMode = isDark ? 'light' : 'dark';
    document.documentElement.dataset.theme = newMode;
    setIsDark(!isDark);
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      <nav id="navbar" className={scrolled ? 'scrolled' : ''}>
        <a href="#hero" className="nav-logo">CA Shetal Parmar</a>
        <ul className="nav-links">
          {['about','exp','skills','certs','edu','tools','cont'].map(id => (
            <li key={id}><a href={`#${id}`}>{id === 'exp' ? 'Experience' : id === 'cont' ? 'Content' : id.charAt(0).toUpperCase() + id.slice(1)}</a></li>
          ))}
        </ul>
        <div className="nav-actions">
          <button className="theme-btn" onClick={toggleMode}>
            {isDark ? '☀️ Light' : '🌙 Dark'}
          </button>
          <a href="#contact" className="btn-primary magnetic">Contact Me</a>
          <button
            className={`hamburger${menuOpen ? ' open' : ''}`}
            id="hamburger-btn"
            aria-label="Menu"
            onClick={() => setMenuOpen(v => !v)}
          >
            <span /><span /><span />
          </button>
        </div>
      </nav>

      <div id="mobile-menu" className={menuOpen ? 'open' : ''}>
        {['about','exp','skills','certs','edu','tools','cont','contact'].map(id => (
          <a key={id} href={`#${id}`} className="mm-link" onClick={closeMenu}>
            {id.charAt(0).toUpperCase() + id.slice(1)}
          </a>
        ))}
      </div>
    </>
  );
}
