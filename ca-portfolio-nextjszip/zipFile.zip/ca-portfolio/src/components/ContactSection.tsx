'use client';
import { motion } from 'framer-motion';
import { useState, FormEvent } from 'react';

export default function ContactSection() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      (e.target as HTMLFormElement).reset();
    }, 3000);
  };

  return (
    <section id="contact" style={{ background: 'var(--bg)' }}>
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7 }}
      >
        <div className="section-label">Contact</div>
        <h2 className="section-title">Let's Connect</h2>
      </motion.div>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1 }}
        style={{ color: 'var(--text-muted)', maxWidth: 580, marginBottom: '3rem', fontSize: '0.95rem' }}
      >
        Open to conversations about audit & assurance roles, tax advisory engagements, business valuation projects, and CA exam guidance. CFOs, founders, fellow CAs, and students are all welcome.
      </motion.p>

      <div className="contact-grid">
        <motion.div
          className="contact-info"
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <div className="contact-item">
            <span className="contact-label">Email</span>
            <a href="mailto:shetal.parmar@email.com" className="contact-val">shetal.parmar@email.com</a>
          </div>
          <div className="contact-item">
            <span className="contact-label">Phone · India</span>
            <a href="tel:+919876543210" className="contact-val">+91 98765 43210</a>
            <span className="contact-sub">WhatsApp & Calls</span>
          </div>
          <div className="contact-item">
            <span className="contact-label">Location</span>
            <span className="contact-val">Ahmedabad, Gujarat · India</span>
            <span className="contact-sub">Open to remote & pan-India engagements</span>
          </div>
          <div className="contact-item">
            <span className="contact-label">LinkedIn</span>
            <a href="#" className="contact-val">linkedin.com/in/shetalparmarca</a>
          </div>
          <a href="#" className="btn-primary magnetic ripple-container" style={{ alignSelf: 'flex-start' }}>
            📅 Schedule a 30-min Call
          </a>
        </motion.div>

        <motion.form
          className="contact-form"
          id="contact-form"
          onSubmit={handleSubmit}
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">First Name</label>
              <input className="form-input" type="text" placeholder="Raj" />
            </div>
            <div className="form-group">
              <label className="form-label">Last Name</label>
              <input className="form-input" type="text" placeholder="Patel" />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input className="form-input" type="email" placeholder="raj@company.com" />
          </div>
          <div className="form-group">
            <label className="form-label">Regarding</label>
            <select className="form-select">
              <option>Statutory Audit Engagement</option>
              <option>GST Advisory / Compliance</option>
              <option>Income Tax Planning</option>
              <option>Business Valuation</option>
              <option>Due Diligence</option>
              <option>Finance Career Guidance</option>
              <option>CA Exam Mentorship</option>
              <option>Other</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Message</label>
            <textarea className="form-textarea" placeholder="Tell me about your requirement…" />
          </div>
          <button
            type="submit"
            className="form-submit magnetic ripple-container"
            style={submitted ? { background: '#2db88a' } : {}}
          >
            {submitted ? "✓ Sent! I'll be in touch soon." : 'Send Message ↗'}
          </button>
        </motion.form>
      </div>
    </section>
  );
}
