'use client';
import { motion } from 'framer-motion';

const CERTS = [
  { icon: '🎓', issuer: 'ICAI', name: 'Chartered Accountant — ACA', desc: 'All three ICAI levels cleared in first attempt. Expertise in finance, audit, taxation, law, and strategic management.', score: '★ All levels · First Attempt' },
  { icon: '📈', issuer: 'SEBI / NISM', name: 'NISM Series X-A — Investment Adviser', desc: 'Securities market, investment advisory regulations, financial planning, and mutual fund advisory framework.', score: 'Score: 82 / 100' },
  { icon: '🔍', issuer: 'SEBI / NISM', name: 'NISM Series VIII — Equity Derivatives', desc: 'Equity derivative instruments, trading strategies, settlement procedures, and SEBI risk framework.', score: 'Score: 88 / 100' },
  { icon: '🏗️', issuer: 'ICAI', name: 'Certificate in Ind AS (IFRS)', desc: 'Comprehensive certification in Indian Accounting Standards including Ind AS 109, 115, 116, and consolidation.', score: 'ICAI Certified' },
  { icon: '🧾', issuer: 'GST Council / ICAI', name: 'GST & Indirect Taxes — Advanced', desc: 'GST litigation, ITC mechanism, GST audit, e-invoicing, and advanced compliance framework for large enterprises.', score: 'Advanced Level' },
  { icon: '+', issuer: 'Multiple Institutions', name: 'Many More Certificates', desc: 'Across finance, compliance, technology and analytics. Available on request from leading institutions.', score: null },
];

export default function CertsSection() {
  return (
    <section id="certs">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7 }}
      >
        <div className="section-label">Certifications</div>
        <h2 className="section-title">Verified Credentials</h2>
      </motion.div>

      <div className="certs-grid">
        {CERTS.map((c, i) => (
          <motion.div
            key={c.name}
            className="cert-card tilt-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
          >
            <div className="card-shine" />
            <div className="cert-icon">{c.icon}</div>
            <div className="cert-issuer">{c.issuer}</div>
            <div className="cert-name">{c.name}</div>
            <div className="cert-desc">{c.desc}</div>
            {c.score && <div className="cert-score">{c.score}</div>}
          </motion.div>
        ))}
      </div>
    </section>
  );
}
