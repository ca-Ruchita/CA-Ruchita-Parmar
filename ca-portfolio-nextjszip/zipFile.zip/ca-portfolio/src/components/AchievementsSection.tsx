'use client';
import { motion } from 'framer-motion';

const ACHS = [
  { icon: '🎤', title: 'Speaker at CA Conclave, Ahmedabad', desc: 'Presented paper on "Impact of Automation & AI on Audit Practices" at ICAI Regional Conference, audience of 600+ professionals.' },
  { icon: '🏆', title: 'Best Article Award — Mehta & Associates', desc: 'Recognised as the best-performing article assistant for three consecutive years for exceptional audit quality and client delivery.' },
  { icon: '🌐', title: '8K+ LinkedIn Finance Network', desc: 'Built a growing community of CA aspirants, finance professionals, and tax practitioners across India through consistent educational content.' },
  { icon: '💡', title: 'Rs.35L+ Tax Savings for Clients', desc: 'Generated cumulative indirect tax savings through ITC optimisation and strategic GST structuring for mid-market clients.' },
  { icon: '🤖', title: 'Tech & AI in Finance', desc: 'Actively applying AI tools, audit analytics, and automation in day-to-day finance and compliance workflows to drive efficiency.' },
  { icon: '❤️', title: 'NGO Finance Volunteer', desc: 'Provides pro-bono accounting, GST filing, and compliance support to registered NGOs and charitable trusts across Gujarat.' },
];

export default function AchievementsSection() {
  return (
    <section id="achievements" style={{ background: 'var(--bg)' }}>
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7 }}
      >
        <div className="section-label">Beyond the Desk</div>
        <h2 className="section-title">Achievements & Impact</h2>
      </motion.div>

      <div className="ach-grid">
        {ACHS.map((a, i) => (
          <motion.div
            key={a.title}
            className="ach-card tilt-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
          >
            <div className="card-shine" />
            <div className="ach-icon">{a.icon}</div>
            <div className="ach-title">{a.title}</div>
            <div className="ach-desc">{a.desc}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
