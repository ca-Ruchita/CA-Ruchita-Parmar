'use client';
import { motion } from 'framer-motion';

interface Tool { icon: string; name: string; desc: string; live: boolean; }

const TOOLS: Tool[] = [
  { icon: '🧾', name: 'GST Invoice Generator', desc: 'Create GST-compliant professional invoices instantly. Perfect for consultants, freelancers, and small businesses.', live: true },
  { icon: '📊', name: 'Income Tax Calculator FY 25-26', desc: 'Old vs New Regime comparison with surcharge, cess, and relief u/s 87A. Optimise your tax liability instantly.', live: true },
  { icon: '📉', name: 'Business Valuation Model', desc: 'DCF with WACC, terminal value, sensitivity tables — built from real valuation and due diligence work.', live: true },
  { icon: '📅', name: 'Compliance Calendar 2025-26', desc: 'Never miss a due date. GST, Income Tax, ROC, TDS — all compliance deadlines in one interactive calendar.', live: true },
  { icon: '🔍', name: 'ITC Eligibility Checker', desc: 'Quick reference tool to determine GST Input Tax Credit eligibility for common business expenses and transactions.', live: true },
  { icon: '🏦', name: 'Audit Risk Assessment Tool', desc: 'AI-assisted audit risk scoring and materiality calculation based on industry benchmarks and financial ratios.', live: false },
];

export default function ToolsSection() {
  return (
    <section id="tools">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7 }}
      >
        <div className="section-label">Finance Lab</div>
        <h2 className="section-title">Tools I've Built</h2>
        <p style={{ color: 'var(--text-muted)', maxWidth: 600, marginTop: '0.75rem', fontSize: '0.95rem' }}>
          Finance professionals should also be builders. These are practical tools crafted from real audit and tax experience, for real decision-making.
        </p>
      </motion.div>

      <div className="tools-grid">
        {TOOLS.map((t, i) => (
          <motion.a
            key={t.name}
            href="#"
            className={`tool-card tilt-card${t.live ? ' live' : ' soon'}`}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
          >
            <div className="card-shine" />
            <div className="tool-top">
              <div className="tool-icon">{t.icon}</div>
              <span className={`tool-status ${t.live ? 'live' : 'soon'}`}>{t.live ? 'Live' : 'Soon'}</span>
            </div>
            <div className="tool-name">{t.name}</div>
            <div className="tool-desc">{t.desc}</div>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
