export default function Footer() {
  return (
    <footer>
      <div>CA Shetal Parmar · ACA · Chartered Accountant · Finance Professional</div>
      <div>© 2026 Shetal Parmar · Ahmedabad, India</div>
    </footer>
  );
}
