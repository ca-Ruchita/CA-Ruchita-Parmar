'use client';
import { motion } from 'framer-motion';

interface ExpEntry {
  period: string;
  badge: string;
  org: string;
  title: string;
  sub: string;
  items: string[];
}

const EXP: ExpEntry[] = [
  {
    period: 'Jan 2024 – Present',
    badge: 'Senior Associate',
    org: 'Deloitte Haskins & Sells LLP',
    title: 'Senior Audit Associate',
    sub: 'Statutory Audit · Mumbai · Big 4 Firm',
    items: [
      'Led statutory audit engagements for <strong>listed companies in BFSI and manufacturing sectors</strong> with revenues exceeding Rs.500 Cr.',
      'Executed <strong>risk-based audit planning</strong>, identifying material misstatements and control weaknesses with actionable management recommendations.',
      'Performed detailed review of <strong>Ind AS / IFRS financial statements</strong> including revenue recognition, lease accounting (Ind AS 116), and financial instruments (Ind AS 109).',
      'Coordinated with client CFOs and controllers, streamlining audit workflows and <em>reducing audit cycle time by 20%</em>.',
      'Mentored a team of 4 article assistants, ensuring quality and timely delivery across concurrent engagements.',
      'Reviewed group consolidation packs and prepared <strong>detailed working papers</strong> for sign-off by engagement partner.',
    ],
  },
  {
    period: 'Jul 2022 – Dec 2023',
    badge: 'Tax Consultant',
    org: 'Grant Thornton Bharat LLP',
    title: 'Tax & Regulatory Consultant',
    sub: 'Direct & Indirect Tax · Ahmedabad · Mid-Tier Firm',
    items: [
      'Managed <strong>GST compliance, advisory, and litigation support</strong> for 40+ clients across retail, pharma, and infrastructure.',
      'Filed <strong>Income Tax returns (ITR-6, ITR-3), tax audit reports (Form 3CD)</strong>, and transfer pricing documentation for domestic companies.',
      'Identified GST input tax credit optimisation opportunities, generating <em>cumulative savings of Rs.35L+</em> for clients.',
      'Prepared representations before GST authorities and assisted in <strong>departmental audits and appeals</strong>.',
      'Drafted <strong>tax due diligence reports</strong> for M&A transactions, identifying exposures and structuring recommendations.',
      'Delivered training sessions on GST amendments and Finance Act provisions to client finance teams.',
    ],
  },
  {
    period: 'Apr 2019 – Jun 2022',
    badge: 'Articleship',
    org: 'Mehta & Associates',
    title: 'Article Assistant',
    sub: 'CA Firm · Ahmedabad · Full-Service Practice',
    items: [
      'Conducted statutory audits across <strong>manufacturing, real estate, retail, and NBFC sectors</strong> with turnovers of Rs.20–300 Cr.',
      'Handled <strong>bank concurrent audits</strong> reviewing loan documentation, KYC compliance, and transaction monitoring.',
      'Prepared financial statements from scratch under <strong>Companies Act, 2013</strong> and Ind AS framework.',
      'GST return filing (GSTR-1, 3B, 9, 9C), reconciliation, and advisory for 25+ clients monthly.',
      'Special assignments: <em>Project financing reports, internal audit for manufacturing units, FEMA compliance reviews</em>.',
    ],
  },
  {
    period: 'Ongoing',
    badge: 'Independent',
    org: 'Self-Practice',
    title: 'Independent CA & Finance Advisor',
    sub: 'Advisory · Compliance · Education',
    items: [
      'Finance and tax advisory for <strong>startups, HNIs, and MSMEs</strong> covering structuring, compliance, and growth strategy.',
      'Creates <strong>LinkedIn content</strong> on CA exam prep, IFRS updates, and finance career guidance for 8,000+ followers.',
      'Actively exploring <strong>AI tools for audit automation, data analytics, and smart financial reporting</strong>.',
    ],
  },
];

export default function ExperienceSection() {
  return (
    <section id="exp">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7 }}
      >
        <div className="section-label">Experience</div>
        <h2 className="section-title">Where I've Built Things</h2>
      </motion.div>

      <div className="exp-list">
        {EXP.map((e, i) => (
          <motion.div
            key={e.title}
            className="exp-card tilt-card"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
          >
            <div className="card-shine" />
            <div className="exp-meta">
              <span className="exp-period">{e.period}</span>
              <span className="exp-badge">{e.badge}</span>
              <span className="exp-org">{e.org}</span>
            </div>
            <div className="exp-body">
              <div className="exp-title">{e.title}</div>
              <div className="exp-sub">{e.sub}</div>
              <ul className="exp-list-items">
                {e.items.map((item, j) => (
                  <li key={j} dangerouslySetInnerHTML={{ __html: item }} />
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
