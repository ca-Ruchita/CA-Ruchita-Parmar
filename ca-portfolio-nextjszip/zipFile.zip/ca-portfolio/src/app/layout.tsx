import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'CA Shetal Parmar | Chartered Accountant · India',
  description:
    'CA Shetal Parmar — Chartered Accountant specialising in Audit & Assurance, Direct & Indirect Taxation, IFRS Reporting, and Business Advisory in India.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" data-color="gold">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=DM+Sans:ital,wght@0,200;0,300;0,400;0,500;1,300&family=Playfair+Display:ital,wght@0,700;0,900;1,700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
