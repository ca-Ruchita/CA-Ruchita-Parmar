import Cursor from '@/components/Cursor';
import ParticleCanvas from '@/components/ParticleCanvas';
import ScrollProgress from '@/components/ScrollProgress';
import Navbar from '@/components/Navbar';
import ThemePanel from '@/components/ThemePanel';
import TiltCards from '@/components/TiltCards';
import InteractionEffects from '@/components/InteractionEffects';
import HeroSection from '@/components/HeroSection';
import Ticker from '@/components/Ticker';
import AboutSection from '@/components/AboutSection';
import ExperienceSection from '@/components/ExperienceSection';
import SkillsSection from '@/components/SkillsSection';
import CertsSection from '@/components/CertsSection';
import EducationSection from '@/components/EducationSection';
import AchievementsSection from '@/components/AchievementsSection';
import ToolsSection from '@/components/ToolsSection';
import ContentSection from '@/components/ContentSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <>
      {/* Global effects */}
      <Cursor />
      <ParticleCanvas />
      <ScrollProgress />
      <TiltCards />
      <InteractionEffects />

      {/* Navigation */}
      <Navbar />
      <ThemePanel />

      {/* Sections */}
      <main>
        <HeroSection />
        <Ticker />
        <AboutSection />
        <div className="grad-sep" />
        <ExperienceSection />
        <div className="grad-sep" />
        <SkillsSection />
        <div className="grad-sep" />
        <CertsSection />
        <div className="grad-sep" />
        <EducationSection />
        <div className="grad-sep" />
        <AchievementsSection />
        <div className="grad-sep" />
        <ToolsSection />
        <div className="grad-sep" />
        <ContentSection />
        <div className="grad-sep" />
        <ContactSection />
      </main>

      <Footer />
    </>
  );
}
